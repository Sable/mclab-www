@compile(['int32','int32'],['int32'])
def fn1(a,b):
    c = a+b
    return c

@compile(['array(float64,1)','array(float64,1)','int32'],['void'])
def fn2(a,b,n):
	for i in xrange(n):
		a[i] = b[i]
	return

@compile(['array(float64,1)','array(float64,1)','int32'],['void'])
def fn3(a,b,n):
	for i in PAR(xrange(n)):
		a[i] = b[i]
	return

@compile(['array(float64,1)','array(float64,1)','int32'],['void'])
def fn4(a,b,n):
	gpu_begin()
	for i in xrange(n):
		a[i] = b[i]
	gpu_end()
	return
