/*
 * grunt-sweet.js
 * https://github.com/natefaubion/grunt-sweet.js
 *
 * Copyright (c) 2013 Nathan Faubion, James Long
 * Licensed under the MIT license.
 */

'use strict';

var path = require('path');
var sweet = require('sweet.js');
var beautify = require('js-beautify').js_beautify;

function sweetCompile(grunt, code, dest, opts, skipCompile) {
    var mapfile = path.basename(dest) + '.map';
    if (skipCompile === true) {
        var expanded = sweet.expand(code, opts.modules, opts);
        var code = expanded.map(function(i) {
            var append = "";
            if(i.token.value !== undefined) {
                if(i.token.type === 4) {
                    append += i.token.value;
                    append += " ";
                } else if(i.token.type === 8) {
                    append += JSON.stringify(i.token.value);
                } else {
                    append += i.token.value;
                }
            }
            return append;
        }).join("");
        var result = { code : beautify(code) };
    } else {
        var result = sweet.compile(code, opts);
    }
    var compiled = result.code;
    grunt.file.write(dest, compiled);
};

module.exports = function(grunt) {
    var moduleCache = {};

    grunt.registerMultiTask('sweetjs', 'Sweeten your JavaScript', function() {
        var options = this.options({
            modules: []
        });

        var moduleContexts = options.modules.map(function(m) {
            return moduleCache[m] || (moduleCache[m] = expandModuleFromCwd(m));
        });

        this.files.forEach(function(f) {
            var src = f.src.filter(function(filepath) {
                if (!grunt.file.exists(filepath)) {
                    grunt.log.warn('Source file "' + filepath + '" not found.');
                    return false;
                } else {
                    return true;
                }
            });

            var lastchar = f.dest && f.dest[f.dest.length - 1];
            var isDir = lastchar && (lastchar === '/' || lastchar === "\\");

            var src = src.map(function(filepath) {
                return grunt.file.read(filepath);
            }).join('\n');

            sweetCompile(grunt, src, f.dest, {
                filename: '<concatenated>',
                modules: moduleContexts,
                readableNames: options.readableNames
            }, options.skipCompile);

        });
    });

    function expandModuleFromCwd(mod) {
        return sweet.loadNodeModule(process.cwd(), mod);
    }
};


