var test = require("tape");
var mn = require("../mcnum");

test("Generator Modules \n Zeros, Ones, Rand, Linspace, Horzcat, Vertcat", function(t) {
    /* Zeros */
    var z1 = mn.zeros();
    t.equals(z1, 0);

    var z2 = mn.zeros(10);
    t.equals(z2.length, 10);
    t.equals(z2.size, 10);
    t.equals(z2.shape.length, 1);
    t.equals(z2.shape[0], 10);
    t.equals(z2.stride[0], 1);
    t.equals(z2.constructor.name, "Float64Array");

    var z3 = mn.zeros([10, 5]);
    t.equals(z3.length, 50);
    t.equals(z3.size, 50);
    t.equals(z3.shape.length, 2);
    t.equals(z3.shape[0], 10);
    t.equals(z3.shape[1], 5);
    t.equals(z3.stride[0], 5);
    t.equals(z3.stride[1], 1);

    var z4 = mn.zeros([5, 4, 10], Int32Array);
    t.equals(z4.length, 200);
    t.equals(z4.size, 200);
    t.equals(z4.shape.length, 3);
    t.equals(z4.shape[0], 5);
    t.equals(z4.shape[1], 4);
    t.equals(z4.shape[2], 10);
    t.equals(z4.stride[0], 40);
    t.equals(z4.stride[1], 10);
    t.equals(z4.stride[2], 1);
    t.equals(z4.constructor.name, "Int32Array");

    /* Ones */
    var o1 = mn.ones();
    t.equals(o1, 1);

    var o2 = mn.ones(10);
    t.equals(o2.length, 10);
    t.equals(o2.size, 10);
    t.equals(o2.shape.length, 1);
    t.equals(o2.shape[0], 10);
    t.equals(o2.stride[0], 1);
    t.equals(o2.constructor.name, "Float64Array");
    t.equals(o2.get(5), 1);
    t.equals(o2.get(0), 1);
    t.equals(o2.get(3), 1);

    var o3 = mn.ones([10, 5]);
    t.equals(o3.length, 50);
    t.equals(o3.size, 50);
    t.equals(o3.shape.length, 2);
    t.equals(o3.shape[0], 10);
    t.equals(o3.shape[1], 5);
    t.equals(o3.stride[0], 5);
    t.equals(o3.stride[1], 1);
    t.equals(o3.get(5,4), 1);
    t.equals(o3.get(0,3), 1);
    t.equals(o3.get(3,2), 1);

    var o4 = mn.ones([5, 4, 10], Uint32Array);
    t.equals(o4.length, 200);
    t.equals(o4.size, 200);
    t.equals(o4.shape.length, 3);
    t.equals(o4.shape[0], 5);
    t.equals(o4.shape[1], 4);
    t.equals(o4.shape[2], 10);
    t.equals(o4.stride[0], 40);
    t.equals(o4.stride[1], 10);
    t.equals(o4.stride[2], 1);
    t.equals(o4.constructor.name, "Uint32Array");
    t.equals(o4.get(4,3,2), 1);
    t.equals(o4.get(2,3,4), 1);
    t.equals(o4.get(3,3,3), 1);

    /* Linspace */
    var l1 = mn.linspace(1,100);
    t.equals(l1.length, 100);
    t.equals(l1.size, 100);
    t.equals(l1.shape.length, 1);
    t.equals(l1.shape[0], 100);
    t.equals(l1.stride[0], 1);
    t.equals(l1.get(15), 16);
    t.equals(l1.get(57), 58);
    t.equals(l1.get(73), 74);

    var l2 = mn.linspace(-1, -12, 12);
    t.equals(l2.length, 12);
    t.equals(l2.size, 12);
    t.equals(l2.shape.length, 1);
    t.equals(l2.shape[0], 12);
    t.equals(l2.stride[0], 1);
    t.equals(l2.get(11), -12);
    t.equals(l2.get(0), -1);
    t.equals(l2.get(7), -8);

    var l3 = mn.linspace(0, 11, 12, Uint8ClampedArray);
    t.equals(l3.length, 12);
    t.equals(l3.size, 12);
    t.equals(l3.shape.length, 1);
    t.equals(l3.shape[0], 12);
    t.equals(l3.stride[0], 1);
    t.equals(l3.get(11), 11);
    t.equals(l3.get(0), 0);
    t.equals(l3.get(7), 7);
    t.equals(l3.constructor.name, "Uint8ClampedArray");

    /* Range */
    var r1 = mn.range(1,100);
    t.equals(r1.length, 100);
    t.equals(r1.size, 100);
    t.equals(r1.shape.length, 1);
    t.equals(r1.shape[0], 100);
    t.equals(r1.stride[0], 1);
    t.equals(r1.get(15), 16);
    t.equals(r1.get(57), 58);
    t.equals(r1.get(73), 74);

    var r2 = mn.range(1, 12, 2);
    t.equals(r2.length, 6);
    t.equals(r2.size, 6);
    t.equals(r2.shape.length, 1);
    t.equals(r2.shape[0], 6);
    t.equals(r2.stride[0], 1);
    t.equals(r2.get(5), 11);
    t.equals(r2.get(0), 1);
    t.equals(r2.get(3), 7);

    var r3 = mn.range(1, -12, -2.2, Int16Array);
    t.equals(r3.length, 6);
    t.equals(r3.size, 6);
    t.equals(r3.shape.length, 1);
    t.equals(r3.shape[0], 6);
    t.equals(r3.stride[0], 1);
    t.equals(r3.get(5), -10);
    t.equals(r3.get(0), 1);
    t.equals(r3.get(3), -5);
    t.equals(r3.constructor.name, "Int16Array");

    var r4 = mn.range(0, 11, 0, Uint8Array);
    t.equals(r4.length, 12);
    t.equals(r4.size, 12);
    t.equals(r4.shape.length, 1);
    t.equals(r4.shape[0], 12);
    t.equals(r4.stride[0], 1);
    t.equals(r4.get(11), 11);
    t.equals(r4.get(0), 0);
    t.equals(r4.get(7), 7);
    t.equals(r4.constructor.name, "Uint8Array");

    t.end();
});
