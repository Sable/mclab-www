var test = require("tape");
var mn = require("../mcnum");

test("Core Modules \n Length, Size, Shape, Stride, Offset, Map, Get, Set, Slice, Transpose", function(t) {
    /* Native Float32Array */

    var f32a1 = new Float32Array(10);
    t.equals(f32a1.length, 10);
    t.equals(f32a1.size, 10);
    t.equals(f32a1.shape.length, 1);
    t.equals(f32a1.shape[0], 10);
    t.equals(f32a1.stride[0], 1);
    t.equals(f32a1.offset, 0);

    var f32a2 = new Float32Array([1,2,3,4,5,6]);
    t.equals(f32a2.length, 6);
    t.equals(f32a2.size, 6);
    t.equals(f32a2.shape.length, 1);
    t.equals(f32a2.shape[0], 6);
    t.equals(f32a2.stride[0], 1);
    t.equals(f32a2.offset, 0);

    var f32a3 = new Float32Array(f32a2);
    t.equals(f32a3.length, 6);
    t.equals(f32a3.size, 6);
    t.equals(f32a3.shape.length, 1);
    t.equals(f32a3.shape[0], 6);
    t.equals(f32a3.stride[0], 1);
    t.equals(f32a3.offset, 0);

    var buffer = f32a2.buffer;
    var f32a4 = new Float32Array(buffer);
    t.equals(f32a4.length, 6);
    t.equals(f32a4.size, 6);
    t.equals(f32a4.shape.length, 1);
    t.equals(f32a4.shape[0], 6);
    t.equals(f32a4.stride[0], 1);
    t.equals(f32a4.offset, 0);

    var f32a5 = new Float32Array(buffer, 4);
    t.equals(f32a5.length, 5);
    t.equals(f32a5.size, 5);
    t.equals(f32a5.shape.length, 1);
    t.equals(f32a5.shape[0], 5);
    t.equals(f32a5.stride[0], 1);
    t.equals(f32a5.offset, 0);

    var f32a6 = new Float32Array(buffer, 4, 2);
    t.equals(f32a6.length, 2);
    t.equals(f32a6.size, 2);
    t.equals(f32a6.shape.length, 1);
    t.equals(f32a6.shape[0], 2);
    t.equals(f32a6.stride[0], 1);
    t.equals(f32a6.offset, 0);

    /* Multi-dimention Float32Array */
    var f32ma1 = new Float32Array(10, [5,2]);
    t.equals(f32ma1.length, 10);
    t.equals(f32ma1.size, 10);
    t.equals(f32ma1.shape.length, 2);
    t.equals(f32ma1.shape[0], 5);
    t.equals(f32ma1.shape[1], 2);
    t.equals(f32ma1.stride[0], 2);
    t.equals(f32ma1.stride[1], 1);
    t.equals(f32ma1.offset, 0);

    var f32ma2 = new Float32Array([1,2,3,4,5,6], [2,3]);
    t.equals(f32ma2.length, 6);
    t.equals(f32ma2.size, 6);
    t.equals(f32ma2.shape.length, 2);
    t.equals(f32ma2.shape[0], 2);
    t.equals(f32ma2.shape[1], 3);
    t.equals(f32ma2.stride[0], 3);
    t.equals(f32ma2.stride[1], 1);
    t.equals(f32ma2.offset, 0);
    t.equals(f32ma2.get(0,0), 1);
    t.equals(f32ma2.get(0,1), 2);
    t.equals(f32ma2.get(0,2), 3);
    t.equals(f32ma2.get(1,0), 4);
    t.equals(f32ma2.get(1,1), 5);
    t.equals(f32ma2.get(1,2), 6);

    var testValue = 1;
    f32ma2.map(function(v, i, a) {
        t.equals(v, testValue++);
    });

    var f32ma3 = new Float32Array(f32ma2);
    t.equals(f32ma3.length, 6);
    t.equals(f32ma3.size, 6);
    t.equals(f32ma3.shape.length, 2);
    t.equals(f32ma3.shape[0], 2);
    t.equals(f32ma3.shape[1], 3);
    t.equals(f32ma3.stride[0], 3);
    t.equals(f32ma3.stride[1], 1);
    t.equals(f32ma3.offset, 0);

    var mBuffer = f32ma2.buffer;
    var f32ma4 = new Float32Array(mBuffer);
    t.equals(f32ma4.length, 6);
    t.equals(f32ma4.size, 6);
    t.equals(f32ma4.shape.length, 1);
    t.equals(f32ma4.shape[0], 6);
    t.equals(f32ma4.stride[0], 1);
    t.equals(f32ma4.offset, 0);

    var f32ma5 = new Float32Array(mBuffer, 8);
    t.equals(f32ma5.length, 4);
    t.equals(f32ma5.size, 4);
    t.equals(f32ma5.shape.length, 1);
    t.equals(f32ma5.shape[0], 4);
    t.equals(f32ma5.stride[0], 1);
    t.equals(f32ma5.offset, 0);

    var f32ma6 = new Float32Array(mBuffer, 8, 2);
    t.equals(f32ma6.length, 2);
    t.equals(f32ma6.size, 2);
    t.equals(f32ma6.shape.length, 1);
    t.equals(f32ma6.shape[0], 2);
    t.equals(f32ma6.stride[0], 1);
    t.equals(f32ma6.offset, 0);

    var f32ma7 = new Float32Array(mBuffer, [2,2], 2);
    t.equals(f32ma7.length, 4);
    t.equals(f32ma7.size, 4);
    t.equals(f32ma7.shape.length, 2);
    t.equals(f32ma7.shape[0], 2);
    t.equals(f32ma7.shape[1], 2);
    t.equals(f32ma7.stride[0], 2);
    t.equals(f32ma7.stride[1], 1);
    t.equals(f32ma7.offset, 0);

    var f32ma8 = new Float32Array(mBuffer, [2,1], 2, 2);
    t.equals(f32ma8.length, 2);
    t.equals(f32ma8.size, 2);
    t.equals(f32ma8.shape.length, 2);
    t.equals(f32ma8.shape[0], 2);
    t.equals(f32ma8.shape[1], 1);
    t.equals(f32ma8.stride[0], 1);
    t.equals(f32ma8.stride[1], 1);
    t.equals(f32ma8.offset, 0);

    /*  */
    var f32ma9 = new Float32Array(f32ma2, [2,2]);
    t.equals(f32ma9.length, 6);
    t.equals(f32ma9.size, 4);
    t.equals(f32ma9.shape.length, 2);
    t.equals(f32ma9.shape[0], 2);
    t.equals(f32ma9.shape[1], 2);
    t.equals(f32ma9.stride[0], 2);
    t.equals(f32ma9.stride[1], 1);
    t.equals(f32ma9.offset, 0);

    var f32ma10 = new Float32Array(f32ma2, [2,2], 0, 2);
    t.equals(f32ma10.length, 6);
    t.equals(f32ma10.size, 4);
    t.equals(f32ma10.shape.length, 2);
    t.equals(f32ma10.shape[0], 2);
    t.equals(f32ma10.shape[1], 2);
    t.equals(f32ma10.stride[0], 2);
    t.equals(f32ma10.stride[1], 1);
    t.equals(f32ma10.offset, 2);

    var f32ma11 = new Float32Array(f32ma2, [2,1], 0, 2, 2);
    t.equals(f32ma11.length, 6);
    t.equals(f32ma11.size, 2);
    t.equals(f32ma11.shape.length, 2);
    t.equals(f32ma11.shape[0], 2);
    t.equals(f32ma11.shape[1], 1);
    t.equals(f32ma11.stride[0], 1);
    t.equals(f32ma11.stride[1], 1);
    t.equals(f32ma11.offset, 2);

    /* N-D Array to Typed Array */
    var f32nda1 = new Float32Array([[1,2],[3,4],[5,6]]);
    t.equals(f32nda1.length, 6);
    t.equals(f32nda1.size, 6);
    t.equals(f32nda1.shape.length, 2);
    t.equals(f32nda1.shape[0], 3);
    t.equals(f32nda1.shape[1], 2);
    t.equals(f32nda1.stride[0], 2);
    t.equals(f32nda1.stride[1], 1);

    var f32nda2 = new Float32Array([[[1,2],[3,4]],[[5,6],[7,8]]]);
    t.equals(f32nda2.length, 8);
    t.equals(f32nda2.size, 8);
    t.equals(f32nda2.shape.length, 3);
    t.equals(f32nda2.shape[0], 2);
    t.equals(f32nda2.shape[1], 2);
    t.equals(f32nda2.shape[2], 2);
    t.equals(f32nda2.stride[0], 4);
    t.equals(f32nda2.stride[1], 2);
    t.equals(f32nda2.stride[2], 1);

    var testValue = 1;
    f32nda2.map(function(v, i, a) {
        t.equals(v, testValue++);
    });

    var f32nda3 = new Float32Array([[1,2,3],[4,5,6]]);
    t.equals(f32nda3.length, 6);
    t.equals(f32nda3.size, 6);
    t.equals(f32nda3.shape.length, 2);
    t.equals(f32nda3.shape[0], 2);
    t.equals(f32nda3.shape[1], 3);
    t.equals(f32nda3.stride[0], 3);
    t.equals(f32nda3.stride[1], 1);

    var testValue = 1;
    f32nda3.map(function(v, i, a) {
        t.equals(testValue++, v);
    });

    /* Transpose */
    var f32ta1 = mn.transpose(new Float32Array(f32ma1));
    t.equals(f32ta1.length, 10);
    t.equals(f32ta1.size, 10);
    t.equals(f32ta1.shape.length, 2);
    t.equals(f32ta1.shape[0], 2);
    t.equals(f32ta1.shape[1], 5);
    t.equals(f32ta1.stride[0], 1);
    t.equals(f32ta1.stride[1], 2);
    t.equals(f32ta1.offset, 0);

    var f32ta2 = mn.transpose(new Float32Array(f32ma2));
    t.equals(f32ta2.length, 6);
    t.equals(f32ta2.size, 6);
    t.equals(f32ta2.shape.length, 2);
    t.equals(f32ta2.shape[0], 3);
    t.equals(f32ta2.shape[1], 2);
    t.equals(f32ta2.stride[0], 1);
    t.equals(f32ta2.stride[1], 3);
    t.equals(f32ta2.offset, 0);
    t.equals(f32ta2.get(0,0), 1);
    t.equals(f32ta2.get(0,1), 4);
    t.equals(f32ta2.get(1,0), 2);
    t.equals(f32ta2.get(1,1), 5);
    t.equals(f32ta2.get(2,0), 3);
    t.equals(f32ta2.get(2,1), 6);

    var testValue = [1, 4, 2, 5, 3, 6];
    var testIndex = 0;
    f32ta2.map(function(v, i, a) {
        t.equals(testValue[testIndex++], v);
    });

    var f32ta7 = mn.transpose((f32ma7));
    t.equals(f32ta7.length, 4);
    t.equals(f32ta7.size, 4);
    t.equals(f32ta7.shape.length, 2);
    t.equals(f32ta7.shape[0], 2);
    t.equals(f32ta7.shape[1], 2);
    t.equals(f32ta7.stride[0], 1);
    t.equals(f32ta7.stride[1], 2);
    t.equals(f32ta7.offset, 0);
    t.equals(f32ta7.get(0,0), 3);
    t.equals(f32ta7.get(0,1), 5);
    t.equals(f32ta7.get(1,0), 4);
    t.equals(f32ta7.get(1,1), 6);

    var testValue = [3,5,4,6];
    var testIndex = 0;
    f32ta7.map(function(v, i, a) {
        t.equals(testValue[testIndex++], v);
    });

    t.end();
});
