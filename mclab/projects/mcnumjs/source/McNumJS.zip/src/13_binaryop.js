BinaryOp add "add" +;
BinaryOp subtract "subtract" -;
BinaryOp dot "dot" *;
BinaryOp divide "divide" /;

// uplus

