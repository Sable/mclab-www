macro VectorScalarOp {
    rule { $y } => {
        s=+s;
        var i=0, l=obj.length;
        if(!out || obj.size != out.size) {
            out = obj.clone();
        }

        NativeIterator(i, l) $y;
        
        return out;
    }
}

macro BinaryOp {
    rule { $fn:ident $fname $op } => {
        exports.$fn = function $fn(obj1, obj2, out) {
            var t = $fname;
            t += obj1.size ? "V" : "S";
            t += obj2.size ? "V" : "S";
            return exports[t](obj1, obj2, out);
        };

        exports.$fn SS = function $fn SS(a, b, out) {
            a=+a; b=+b;
            out = +(a $op b);
            return out;
        };

        exports.$fn SV = function $fn SV(s, obj, out) {
            VectorScalarOp {
                out[i] = s $op obj[i];
            };
        };

        exports.$fn VS = function $fn VS(obj, s, out) {
            VectorScalarOp {
                out[i] = obj[i] $op s;
            };
        };

        exports.$fn VV = function $fn VV(obj1, obj2, out) {
            var shape1 = obj1.shape[0],
                shape2 = obj1.shape[1], i=0, size=obj1.size|0;

            if(!out || size != out.size) {
                out = obj1.clone(size, obj1.shape);
            }

            NativeIterator(i, size) {
                out[i] = (obj1[i]|0) $op (obj2[i]|0);
            }

            return out;
        };

        exports.$fn eq = function $fn eq(obj1, obj2) {
            return exports.$fn(obj1, obj2, obj1);
        }
    }
}

