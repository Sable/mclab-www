exports.zeros = function zeros(dimension, className) {
    className = className || Float64Array;
    var mul=1;

    if(!dimension) {
        return 0;
    }

    if(!dimension.length) {
        mul = dimension|0;
        dimension = [mul];
    } else {
        var l = dimension.length|0;
        mul = 1;

        for(var i=0; (i<l)|0; (++i)|0) {
            mul = (mul * dimension[i])|0;
        }
    }

    return new className(mul, dimension);
}

exports.ones = function ones(dimension, className) {
    className = className || Float64Array;
    var mul=1, obj;

    if(!dimension) {
        return 1;
    }

    if(!dimension.length) {
        mul = dimension|0;
        dimension = [mul];
    } else {
        var l = dimension.length|0;
        mul = 1;

        for(var i=0; (i<l)|0; (++i)|0) {
            mul = (mul * dimension[i])|0;
        }
    }

    obj = new className(mul, dimension);

    NativeIterator(i, mul) {
        obj[i] = 1;
    }

    return obj;
}

exports.rand = function rand(dimension, className) {
    className = className || Float64Array;
    var mul=1, obj;

    if(!dimension) {
        return Math.random();
    }

    if(!dimension.length) {
        mul = dimension|0;
        dimension = [mul];
    } else {
        var l = dimension.length|0;
        mul = 1;

        for(var i=0; (i<l)|0; (++i)|0) {
            mul = (mul * dimension[i])|0;
        }
    }

    obj = new className(mul, dimension);

    NativeIterator(i, mul) {
        obj[i] = Math.random();
    }

    return obj;
}

exports.linspace = function linspace(start, stop, n, className) {
    start = +start; stop = +stop; n = n|0;
    className = className || Float64Array;

    if(n<1) n=100;
    if(n==1) {
        return new className([start], [1], [1], 0);
    }

    step = (stop-start)/(+(n-1));
    return exports.private.allocateRange(start, stop, step, n, className);
}

exports.range = function range(start, stop, step, className) {
    start = +start; stop = +stop; 
    className = className || Float64Array;
    if(!step) {
        step = stop < start ? -1 : 1;
    }
    step = +step;
    var n = ~~Math.floor((stop - start + (step < 0 ? -1 : 1))/step);

    if(n <= 1) {
        return new className([start], [1], [1], 0);
    }

    return exports.private.allocateRange(start, stop, step, n, className);
}

exports.identity = function identity(n, className) {
    n = +n;
    className = className || Float64Array;
    
    var i=0, obj = new className(n*n, [n,n], [n,1]);

    for(;i<n; i++) {
        obj[i*n + i] = 1;
    }

    return obj;
}

exports.private.allocateRange = function _allocateRange(start, stop, step, n, className) {
    start = +start; stop = +stop; step = +step, n = n|0;

    var obj = new className(n, [n], [1], 0);

    NativeIterator(i, n) {
        obj[i] = start;
        start += step;
    }

    return obj;
}
