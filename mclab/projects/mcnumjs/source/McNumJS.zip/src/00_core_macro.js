/* Add methods to typed ArrayBufferView objects and creating new methods */
macro TypedArrayView {
    rule {
        ($x, $y, $z);
    } => {
        var $y = $x;
        (function() {
            exports.types.push($x .name);
            $y.prototype.STRIDED=false;

            $y.prototype.map = function $y map(callback) {
                var shape = this.shape, stride = this.stride, i=this.offset|0, current=new I32A(shape.length);

                if(!this.STRIDED) {
                    for(; i<this.size; i++|0) {
                        this[i] = callback.call(this[i], this[i], current, this) || this[i];
                    }
                } else {
                    for(; i>-1; i=exports.private.getNextIndex(i, current, shape, stride)|0) {
                        this[i] = callback.call(this[i], this[i], current, this) || this[i];
                    }
                }
                return this;
            };

            $x = function $x Construct(data, shape, stride, offset, length, byteOffset) {
                offset=offset|0;
                length=length|0;

                var obj, i=0, size=1, d=0, offsetReal=0;

                if(data.constructor.name === "ArrayBuffer") {
                    if(!shape || !shape.length) {
                        offsetReal = shape>>>0;
                        shape = stride ? [stride] : [(data.byteLength - offsetReal)/$z];
                        length = stride || ((data.byteLength - offsetReal)/$z);
                        stride = [1];
                        offset=0;
                    } else if (!stride || !stride.length) {
                        offsetReal = (stride*$z)>>>0;
                        length = offset || ((data.byteLength - offsetReal)/$z);
                        offset = 0;
                    } else {
                        offsetReal = byteOffset|0;
                    }
                } else if(data.length && data[0].length) {
                    shape = [data.length|0];
                    while(data[0].length) {
                        shape.push(data[0].length|0);
                        data = exports.private.flatten(data);
                    }
                }

                obj = new $y(data, offsetReal, length);

                if(!shape || !shape.length) {
                    if(!data.shape || !data.shape.length) {
                        shape = [obj.length];
                    } else {
                        shape = data.shape;
                    }
                }

                d = shape.length;
                if(!stride || !stride.length) {
                    stride = new Array(d);
                    for(i=(d-1)|0; i>=0; (--i)|0) {
                        stride[i] = size;
                        size *= shape[i];
                    }
                } else {
                    for(i=(d-1)|0; i>=0; (--i)|0) {
                        size *= shape[i];
                    }
                }

                var indexArg = [], code = "(this.offset|0)";

                for(i=0; i<d; (i++)|0) {
                    code = code + "+" + stride[i] + "*(i" + i + "|0)";
                    indexArg.push("i" + i);
                }

                var index = new Function(indexArg, "return "+ code + ";");
                var get = new Function(indexArg, "return this[" + code + "];");
                var set = new Function(indexArg, "value", "this[" + code + "] = value;");

                Object.defineProperty(obj, "shape", { __proto__: null, value: new I32A(shape) });
                Object.defineProperty(obj, "stride", { __proto__: null, value: new I32A(stride) });
                Object.defineProperty(obj, "offset", { __proto__: null, value: (offset|0) });
                Object.defineProperty(obj, "size", { __proto__: null, value: (size|0) });
                
                Object.defineProperty(obj, "index", { __proto__: null, value: index });
                Object.defineProperty(obj, "get", { __proto__: null, value: get });
                Object.defineProperty(obj, "set", { __proto__: null, value: set });

                return obj;
            };

            function $y Clone(size, shape) {
                var obj;
                if(!size) {
                    obj = new $x(this, this.shape, this.stride, this.offset);
                    obj.STRIDED = this.STRIDED;
                } else if(!shape.length) {
                    obj = new $x(size);
                } else {
                    obj = new $x(size, shape);
                }
                return obj;
            };

            function $y Reshape(shape) {
                return new $x(this.buffer, shape, 0, this.offset, this.length, this.byteOffset);
            };

            function $y Slice(lower, upper) {
                var i=0, l=this.shape.length, off=this.offset;

                for(i=0; i<l; (++i)|0) {
                    if(upper[i]|0 < 0) {
                        upper[i] = this.shape[i];
                    }
                    if(lower[i]|0 >= 0) {
                        var temp=lower[i]|0;
                        off += (this.stride[i]*temp)|0;
                        lower[i] = (upper[i]-temp)|0;
                    }
                }

                var obj = new $x(this.buffer, lower, 0, off, this.length, this.byteOffset);
                obj.STRIDED = true;
                return obj;
            };

            Object.defineProperty($y.prototype, "clone", { __proto__: null, value: $y Clone });
            Object.defineProperty($y.prototype, "reshape", { __proto__: null, value: $y Reshape });
            Object.defineProperty($y.prototype, "slice", { __proto__: null, value: $y Slice });
            Object.defineProperty($y.prototype, "class", { __proto__: null, value: $x });
        }());
    }
}

