/* Create main objects */

var mn = (typeof exports === "undefined")?(exports = {}):(exports);
if(typeof global !== "undefined") { global.mn = exports; }

exports.double = {}
exports.int = {};

exports.types = [];		   // List of supported types by the library
exports.private = {};	   // Private functions used by library

exports.private.flatten = function _flatten_array(arr) {
    return [].concat.apply([],arr);
};

exports.private.getNextIndex = function _getNextIndex(i, current, shape, stride) {
    i=i|0;
    var l = shape.length|0;

    while((--l) >= 0 && (++current[l]>=shape[l])) {
        i -= (--current[l]*stride[l])|0;
        current[l] = 0;
    }
    if(l<0) {
        return -1;
    }
    
    return i+stride[l];
};

exports.private.transposeDimension = function _transposeStride_exports(obj, dim1, dim2) {
	var i=0, l=obj.length, newDim=Array.apply([],obj);

    dim1=dim1|0;
    dim2=dim2|0||1;

    if (l === 1) {
        newDim = [1, obj[0]];
        l=2;
    }

    if(dim1 < l && dim2 < l) {
        var t = newDim[dim1];
        newDim[dim1] = newDim[dim2];
        newDim[dim2] = t;
    }

    return newDim;
};

/*exports.private.getValue = function $y Get(obj, index) {
    var l=obj.stride.length, sum=0;
    for(var i=0; i<l; i++) {
        sum = sum + (obj.stride[i]|0)*(index[i]|0);
    }
    return obj[sum];
}

exports.private.setValue = function $y Set(obj, index, value) {
    var l=obj.stride.length, sum=0;
    for(var i=0; i<l; i++) {
        sum = sum + (obj.stride[i]|0)*(index[i]|0);
    }
    obj[sum] = value;
}*/

/* Override Typed ArrayBufferView Objects */
TypedArrayView(Int32Array, I32A, 4);
TypedArrayView(Int16Array, I16A, 2);
TypedArrayView(Int8Array, I8A, 1);
TypedArrayView(Uint32Array, UI32A, 4);
TypedArrayView(Uint16Array, UI16A, 2);
TypedArrayView(Uint8Array, UI8A, 1);
TypedArrayView(Uint8ClampedArray, UI8CA, 1);
TypedArrayView(Float32Array, F32A, 4);
TypedArrayView(Float64Array, F64A, 8);

