UnaryOp fill (val) () { obj[i] = val; } { obj = val; } obj;
UnaryOp negate () () { obj[i] = -1*obj[i]; } { obj = -1*obj; } obj;

UnaryFnOp sin
UnaryFnOp cos
UnaryFnOp abs
UnaryFnOp sqrt
UnaryFnOp exp
UnaryFnOp ceil
UnaryFnOp floor
UnaryFnOp round

UnaryOp sum () (s=0.0) { s += obj[i]; } { s += obj; } s;
UnaryOp average () (s=0.0) { s += obj[i]; } { s+= obj; n=1; } (s/n);
UnaryOp norm2 () (s=0.0) { s += (obj[i]*obj[i]); } { s += obj*obj; } (+Math.sqrt(s));

exports.transpose = function transpose(obj, dim1, dim2) {
    var newShape = exports.private.transposeDimension(obj.shape, dim1, dim2), newStride = exports.private.transposeDimension(obj.stride, dim1, dim2);
    var ret = new obj.class(obj.buffer, newShape, newStride, obj.offset, obj.length, obj.byteOffset);
    ret.STRIDED = true;
    return ret;
};

// uplus
// neg
// length
