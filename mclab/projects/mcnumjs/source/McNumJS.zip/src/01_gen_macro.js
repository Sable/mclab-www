macro NativeIterator {
    rule {
        ($i:ident, $l:ident) $y
    } => {
        for(var $i=0; $i<$l; ($i++)|0) 
            $y
    }
}
