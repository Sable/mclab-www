macro UnaryOp {
    rule { $fn:ident ($($id1) (,) ...) ( $($id = $val) (,) ...) $y $s $z } => {
        exports.$fn = function $fn(obj $($id1,)...) {
            $($id1 = +$id1;) ...
            $(var $id = $val;) ...
            var i=0, n = obj.length|0;

            if(n !== obj.size) {
                obj.map(function(v,i,obj) $y);
            } else {
                NativeIterator(i, n) $y
            }

            return $z;
        }
    }
}

macro UnaryFnOp {
    rule { $fn:ident } => {
        exports.$fn = function $fn(obj) {
            var i=0, n = obj.length|0;
            if(n > 0) {
                exports.$fn V(obj);
            } else {
                obj = +Math.$fn(obj);
            }
            return obj;
        };

        exports.$fn V = function $fn V(obj) {
            var i=0, n = obj.length|0;
            if(n !== obj.size) {
                obj.map(function(v) {
                    return +Math.$fn(v);
                });
            } else {
                NativeIterator(i, n) {
                    obj[i] = +Math.$fn(obj[i]);
                }
            }
            return obj;
        };

    }
}
