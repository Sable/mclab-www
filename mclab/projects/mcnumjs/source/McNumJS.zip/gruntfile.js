'use strict';

module.exports = function(grunt) {
    grunt.initConfig({
        pkg: grunt.file.readJSON('package.json'),

        dir: {
            src: './src',
            dist: '.',
            js: 'js',
        },

        clean: ['<%= dir.dist %>/<%= pkg.name %>.*.js', '<%= dir.dist %>/<%= pkg.name %>.js'],

        concat: {
            dist: {
                src: ['<%= dir.src %>/*.js'],
                dest: '<%= dir.dist %>/<%= pkg.name %>.js'
            }
        },

        sweetjs: {
            options: {
                readableNames: true,
                skipCompile: true
            },
            compile: {
                src: '<%= dir.dist %>/<%= pkg.name %>.js',
                dest: '<%= dir.dist %>/<%= pkg.name %>.js'
            }
        },

        uglify: {
            dist: {
                src: ['<%= dir.dist %>/<%= pkg.name %>.js'],
                dest: '<%= dir.dist %>/<%= pkg.name %>.min.js'
            }
        },

        tape: {
            files: ["tests/*.js"]
        }
    });

    grunt.loadNpmTasks('grunt-contrib-uglify');
    grunt.loadNpmTasks('grunt-contrib-concat');
    grunt.loadNpmTasks('grunt-contrib-clean');
    grunt.loadNpmTasks('grunt-tape');
    require('./pkg/sweetjs')(grunt);

    grunt.registerTask('default', ['clean', 'concat', 'sweetjs', 'uglify']);
    grunt.registerTask('test', ['tape']);
};

