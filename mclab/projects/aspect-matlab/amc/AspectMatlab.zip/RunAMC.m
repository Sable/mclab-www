%Runs the AMC GUI interface. Ensure that the AMC directory is in the
%working directory.


javaaddpath(strcat(pwd,'/AMC'))
javaaddpath(strcat(pwd,'/AMC/amc.jar'))
NewAspectMatlabGUI.buildGUI(pwd);
