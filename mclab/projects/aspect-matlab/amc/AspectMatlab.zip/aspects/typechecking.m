aspect typechecking
  properties
    %container associating variable name with class type
    varclass = containers.Map
    %container associating variable name with dimensions
    vardims = containers.Map
    %container associating string literals with dimension value
    chardims = containers.Map
  end

  patterns
    typeAnn : annote(type(var, char, [*]));
    arraySet : set(*);
  end
  
  actions
    actAnn : before typeAnn : (args, rep, line);
        %context expose of args gives the arguments provided by the
        %annotation in order 
        %context expose of rep gives the string representation of the 
        %annotation arguments, which we use to obtain a string
        %representation of the variable
        %first argument is a the variable we check
        %second argument is the expected class of the variable
        %third argument is an array containing the dimensions
        value = args{1};
        varname = rep{1};
        expectedclass = args{2};
        expecteddims = args{3};

        %if the variable is defined at the point of the annotation, we 
        %immediately perform type checking, throwing an error if
        %requirements are not met.
        if(isa(value,'AMundef'))
            dimensions = dims(value);
            if((ndims(value) ~= size(expecteddims,1)) ) 
                errmsg = ['Type Error: Dimension requirements not met at annotation on line ',line, '. ',varname,' was is expected to have ',num2str(size(expecteddims,1)),' dimensions, but instead had ',num2str(ndims(value)),'.'];
                error(errmsg);
            end
            if(~isa(value,expectedclass)) 
                errmsg = ['Type Error: Class requirements not met at annotation on line ',line, '. ',varname,' was is expected to have type ',expectedclass,' but instead had type ',class(value),'.'];
                error(errmsg)
            end
            
            for dim = 1:size(expecteddims,1)
                if(isa(expecteddims{dim},'char')
                   %check against any previous definition for the string
                    if (ismember(expecteddims{dim}, keys(chardims)))
                        if(size(value,dim)~= chardims(expecteddims{dim}))
                            %preparting dimensions for error message, convert to
                            %string and add commas
                            comma = [cellfun(@num2str,dimensions,'UniformOutput',0)];
                            comma(2,:) = {','};
                            dimout = [comma{:}];
                            errmsg = ['Type Error: Size requirements not met at annotation on line ',line, '. ',varname,' was is expected to have dimensions [',dimout,'] but instead had dimensions ',size(value),'.'];                     
                            end
                     else
                    %associate value with string if no previous definition
                    %exists
                    chardims(expecteddims{dim}) = size(value,dim);
                    end
           
                               
               elseif(size(value,dim) ~= dimensions{dim})
                    %preparting dimensions for error message, convert to
                    %string and add commas
                    comma = [cellfun(@num2str,dimensions,'UniformOutput',0)];
                    comma(2,:) = {','};
                    dimout = [comma{:}];
                    errmsg = ['Type Error: Size requirements not met at annotation on line ',line, '. ',varname,' was is expected to have dimensions [',dimout,'] but instead had dimensions ',size(value),'.'];                     
               end
            end
        end
        %Whether it exists or not, we associate the variable name with the expected class and dimensions
        varclass(varname) = expectedclass;
        vardims(varname) = expecteddims;
        
      end
        
            

	  
	actArraySet : after arraySet : (newval, name, line)
        if(ismember(name, keys(varclass)))
            dimensions = dims(newval);
            expectedclass = keys(varclass);
            expecteddims = keys(vardims);
            if((ndims(newval) ~= size(expecteddims,1)) ) 
                errmsg = ['Type Error: Dimension requirements not met at annotation on line ',line, '. ',name,' was is expected to have ',num2str(size(expecteddims,1)),' dimensions, but instead had ',num2str(ndims(newval)),'.'];
                error(errmsg);
            end
            if(~isa(newval,expectedclass)) 
                errmsg = ['Type Error: Class requirements not met at annotation on line ',line, '. ',name,' was is expected to have type ',expectedclass,' but instead had type ',class(newval),'.'];
                error(errmsg)
            end
            
            for dim = 1:size(expecteddims,1)
                if(isa(expecteddims{dim},'char')
                   %check against any previous definition for the string
                    if (ismember(expecteddims{dim}, keys(chardims)))
                        if(size(newval,dim)~= chardims(expecteddims{dim}))
                            %preparting dimensions for error message, convert to
                            %string and add commas
                            comma = [cellfun(@num2str,dimensions,'UniformOutput',0)];
                            comma(2,:) = {','};
                            dimout = [comma{:}];
                            errmsg = ['Type Error: Size requirements not met at annotation on line ',line, '. ',name,' was is expected to have dimensions [',dimout,'] but instead had dimensions ',size(newval),'.'];                     
                            end
                     else
                    %associate value with string if no previous definition
                    %exists
                    chardims(expecteddims{dim}) = size(newval,dim);
                    end
           
                               
               elseif(size(newval,dim) ~= dimensions{dim})
                    %preparting dimensions for error message, convert to
                    %string and add commas
                    comma = [cellfun(@num2str,dimensions,'UniformOutput',0)];
                    comma(2,:) = {','};
                    dimout = [comma{:}];
                    errmsg = ['Type Error: Size requirements not met at annotation on line ',line, '. ',name,' was is expected to have dimensions [',dimout,'] but instead had dimensions ',size(newval),'.'];                     
               end
            end
        end
     end
  end
end