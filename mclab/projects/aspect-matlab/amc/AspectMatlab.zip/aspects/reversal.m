aspect reversal

	actions
		reversal : around loopp : (looptype, obj)
			if(strcmp(looptype,'for'))
				i = size(obj);
				while(i>0)
					loopiterator = obj(i)
					body()
					i = i-1;
				end
			end
		end
	end
end