aspect profileoned
	properties
		columnvars = container.Map;
		rowvars = container.Map;
 	end

	patterns
		onedcolumn : set(*)&dimension(1,*);
		onedrow : set(*)&dimension(*,1);
		exec : mainexecution();
	end

	actions
		actColumn : after onedcolumn : (name,line)
			%Store the name of the variable, the line it
			%occured on, and its orientation
			columnslines = columnvars[name]
			if(~ismember(columnslines,line))
				columnvars[name] = [columnslines line]
			end
		end
		
		
		actRow : after onedrow : (name,line)
			%Store the name of the variable, the line it
			%occured on, and its orientation
			rowslines = rowsvars[name]
			if(~ismember(rowslines,line))
				rowvars[name] = [rowslines line]
			end
		end
	

	
		results : after exec
		% will display the results
		disp('The following variables had horizontal orientation at the corresponding lines');
		result = {'var','lines'};
		for i=keys(rowvars) %iterate over variables
			result{i+1,1} = i;
			result{i+1,2} = rowvars(i);
		end
		disp(result);
		disp('The following variables had vertical orientation at the corresponding lines');
				result = {'var','lines'};
		for i=keys(columnvars) %iterate over variables
			result{i+1,1} = i;
			result{i+1,2} = columnvars(i);
		end
		disp(result);
		end
	end
end