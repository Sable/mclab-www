aspect safeindex
	properties
		nonrealint = container.Map;
	end

	patterns
		realint : get(*)&type(¬realinteger);
		exec : mainexecution();
	end
	actions
		actRealInt : after realint : (name,line)
		%Store the name and line of the variable, if it
		%has not already been stored.
		unrealintlines = nonrealint[name]
		if(~ismember(unrealintlines,line))
			nonrealint[name] = [unrealintlines,line]
		end
	end
	
	results : after exec
		% will display the results
		disp('The following variables were assigned values that were not real positive integers at the corresponding lines');
		result = {'var','lines'};
		for i=keys(nonrealint) %iterate over variables
			result{i+1,1} = i;
			result{i+1,2} = nonrealint(i);
		end
		disp(result);

	end
end