aspect unroll
	properties
		numunroll = 2;
	end

	patterns
		annUnroll : annote(unroll(int));
		loopp : loopbody(*);
	end

	actions
		actUnroll : after annUnroll : (args)
		numunroll = args{1}
	end

	unroll2 : around loopp : (looptype, obj)
		if(strcmp(looptype,'for') && unrollvalue == 2)
			i = 0;
			while(i<(size(obj)-2)
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
			end
			while(i<size(obj)
				i = i+1;
				loopiterator = obj(i)
				body()
			end
		end
	end
	
	unroll3 : around loopp : (looptype, obj)
		if(strcmp(looptype,'for') && unrollvalue == 3)
			i = 0;
			while(i<(size(obj)-3)
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
			end
			while(i<size(obj)
				i = i+1;
				loopiterator = obj(i)
				body()
			end
		end
	end
	
	unroll4 : around loopp : (looptype, obj)
		if(strcmp(looptype,'for') && unrollvalue == 4)
			i = 0;
			while(i<(size(obj)-4)
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
			end
			while(i<size(obj)
				i = i+1;
				loopiterator = obj(i)
				body()
			end
		end
	end
	
		
	unroll5 : around loopp : (looptype, obj)
		if(strcmp(looptype,'for') && unrollvalue == 5)
			i = 0;
			while(i<(size(obj)-5)
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
			end
			while(i<size(obj)
				i = i+1;
				loopiterator = obj(i)
				body()
			end
		end
	end
	
	unroll10 : around loopp : (looptype, obj)
		if(strcmp(looptype,'for') && unrollvalue == 10)
			i = 0;
			while(i<(size(obj)-10)
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
				i = i+1;
				loopiterator = obj(i)
				body()
			end
			while(i<size(obj)
				i = i+1;
				loopiterator = obj(i)
				body()
			end
		end
	end
	
end
