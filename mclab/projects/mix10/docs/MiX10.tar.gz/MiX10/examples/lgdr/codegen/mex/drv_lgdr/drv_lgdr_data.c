/*
 * drv_lgdr_data.c
 *
 * Code generation for function 'drv_lgdr_data'
 *
 * C source code generated on: Mon Mar  3 05:15:50 2014
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "drv_lgdr.h"
#include "drv_lgdr_data.h"

/* Variable Definitions */
const volatile char_T *emlrtBreakCheckR2012bFlagVar;
emlrtRSInfo e_emlrtRSI = { 14, "sqrt",
  "/usr/local/pkgs/MATLAB/R2013a/toolbox/eml/lib/matlab/elfun/sqrt.m" };

emlrtRSInfo f_emlrtRSI = { 20, "eml_error",
  "/usr/local/pkgs/MATLAB/R2013a/toolbox/eml/lib/matlab/eml/eml_error.m" };

emlrtRTEInfo b_emlrtRTEI = { 20, 5, "eml_error",
  "/usr/local/pkgs/MATLAB/R2013a/toolbox/eml/lib/matlab/eml/eml_error.m" };

/* End of code generation (drv_lgdr_data.c) */
