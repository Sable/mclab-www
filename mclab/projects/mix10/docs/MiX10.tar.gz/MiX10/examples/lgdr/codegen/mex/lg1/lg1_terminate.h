/*
 * lg1_terminate.h
 *
 * Code generation for function 'lg1_terminate'
 *
 * C source code generated on: Mon Mar  3 12:17:58 2014
 *
 */

#ifndef __LG1_TERMINATE_H__
#define __LG1_TERMINATE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "lg1_types.h"

/* Function Declarations */
extern void lg1_atexit(void);
extern void lg1_terminate(void);
#endif
/* End of code generation (lg1_terminate.h) */
