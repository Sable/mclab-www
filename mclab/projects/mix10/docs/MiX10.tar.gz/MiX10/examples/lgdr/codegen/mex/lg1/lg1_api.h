/*
 * lg1_api.h
 *
 * Code generation for function 'lg1_api'
 *
 * C source code generated on: Mon Mar  3 12:17:58 2014
 *
 */

#ifndef __LG1_API_H__
#define __LG1_API_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "lg1_types.h"

/* Function Declarations */
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
extern void lg1_api(const mxArray * const prhs[1]);
#endif
/* End of code generation (lg1_api.h) */
