/*
 * lg1_types.h
 *
 * Code generation for function 'lg1'
 *
 * C source code generated on: Mon Mar  3 12:17:58 2014
 *
 */

#ifndef __LG1_TYPES_H__
#define __LG1_TYPES_H__

/* Include files */
#include "rtwtypes.h"

#endif
/* End of code generation (lg1_types.h) */
