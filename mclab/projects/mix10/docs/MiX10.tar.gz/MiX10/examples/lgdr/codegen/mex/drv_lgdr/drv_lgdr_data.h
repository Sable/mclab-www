/*
 * drv_lgdr_data.h
 *
 * Code generation for function 'drv_lgdr_data'
 *
 * C source code generated on: Mon Mar  3 05:15:50 2014
 *
 */

#ifndef __DRV_LGDR_DATA_H__
#define __DRV_LGDR_DATA_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "drv_lgdr_types.h"

/* Variable Declarations */
extern const volatile char_T *emlrtBreakCheckR2012bFlagVar;
extern emlrtRSInfo e_emlrtRSI;
extern emlrtRSInfo f_emlrtRSI;
extern emlrtRTEInfo b_emlrtRTEI;
#endif
/* End of code generation (drv_lgdr_data.h) */
