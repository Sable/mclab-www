tic
lg1(165000);
toc

tic
lg1_mex(165000);
toc

