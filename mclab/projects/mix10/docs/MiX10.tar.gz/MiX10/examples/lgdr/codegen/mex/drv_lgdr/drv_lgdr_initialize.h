/*
 * drv_lgdr_initialize.h
 *
 * Code generation for function 'drv_lgdr_initialize'
 *
 * C source code generated on: Mon Mar  3 05:15:50 2014
 *
 */

#ifndef __DRV_LGDR_INITIALIZE_H__
#define __DRV_LGDR_INITIALIZE_H__
/* Include files */
#include <math.h>
#include <stdlib.h>
#include <string.h>

#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "blas.h"
#include "rtwtypes.h"
#include "drv_lgdr_types.h"

/* Function Declarations */
extern void drv_lgdr_initialize(emlrtContext *aContext);
#endif
/* End of code generation (drv_lgdr_initialize.h) */
