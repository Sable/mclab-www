tic
drv_lgdr(165000);
toc

tic
drv_lgdr_mex(165000);
toc

