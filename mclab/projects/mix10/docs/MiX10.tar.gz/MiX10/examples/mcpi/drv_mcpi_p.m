function res = drv_mcpi_p(scale)
%tic
 res = mcpi_p(scale,50000);
%toc
end


