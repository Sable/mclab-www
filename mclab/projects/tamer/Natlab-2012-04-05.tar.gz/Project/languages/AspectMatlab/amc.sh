#!/bin/bash
			java -jar /home/2008/osavary/workspace/Matlab Source/languages/AspectMatlab/amc.jar $*