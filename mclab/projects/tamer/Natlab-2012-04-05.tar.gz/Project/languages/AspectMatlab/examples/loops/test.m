function test
% the following script shows some example uses for the loops aspect
for i = 1:2:99
	%disp({'Lower Bound i: ', lBound});
	%disp({'Upper Bound i: ', uBound});

	for j = 10:-1:1
		%disp({'Lower Bound j: ', lBound});
		%disp({'Upper Bound j: ', uBound});
		%disp({'Increment j: ', increment});
		%disp({'Iteration j: ', iteration});
	end

	%disp({'Increment i: ', increment});
	%disp({'Iteration i: ', iteration});
end
end