function program()
  solveHeatEquation(.01,500);
end



