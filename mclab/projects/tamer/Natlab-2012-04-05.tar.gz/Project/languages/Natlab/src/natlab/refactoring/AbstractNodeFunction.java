package natlab.refactoring;

public abstract class AbstractNodeFunction<T> {
	public abstract void apply(T node);
}
