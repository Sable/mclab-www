package natlab.toolkits.analysis.isscalar;

public class Scalar extends IsScalarType {

	@Override
	public String toString() {
		return "scalar";
	}
}
