package natlab.toolkits.analysis.isscalar;

public class Bottom extends IsScalarType {

	@Override
	public String toString() {
		return "bottom";
	}
}
