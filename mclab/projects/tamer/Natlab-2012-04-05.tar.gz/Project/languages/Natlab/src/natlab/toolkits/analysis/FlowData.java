package natlab.toolkits.analysis;

import java.util.*;



/**
 * Interface intended to represent flow data. This is primarily
 * intended to tag a class as representing flow data. 
 *
 * @author Jesse Doherty
 */
public interface FlowData
{


}
