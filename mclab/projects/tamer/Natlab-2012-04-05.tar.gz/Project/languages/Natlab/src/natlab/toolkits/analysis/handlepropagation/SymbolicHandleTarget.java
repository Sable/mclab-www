package natlab.toolkits.analysis.handlepropagation;

/**
 * Represents handle targets that are not concretely known. These
 * include targets that come from function arguments. 
 */