package natlab.tame.valueanalysis.components.complex;

/**
 * a class that denotes complex information
 * Vineet -- this is a lattice element in your complex analysis
 * should this be an enum?
 *
 */
public class ComplexInfo {

}
