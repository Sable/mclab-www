package natlab.tame.tir;

import ast.TryStmt;

public class TIRTryStmt extends TryStmt {
    private static final long serialVersionUID = 1L;

    public TIRTryStmt(TIRStatementList p0, TIRStatementList p1){
        super(p0, p1);
    }
}
