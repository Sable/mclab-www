package natlab.toolkits.analysis.callgraph;

/**
 * Represents labels for call sites from function handles
 */
public class HandleCallSiteLabel
{


}
