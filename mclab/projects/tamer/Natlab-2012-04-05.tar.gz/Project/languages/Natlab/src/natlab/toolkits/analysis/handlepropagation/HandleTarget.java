package natlab.toolkits.analysis.handlepropagation;


/**
 *
 * NamedHandleTarget, AnonymousHandleTarget
 */
public interface HandleTarget extends Comparable<HandleTarget>
{




}