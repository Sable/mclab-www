package natlab.toolkits.analysis.isscalar;

public class Top extends IsScalarType {
	
	@Override
	public String toString() {
		return "top";
	}
}
