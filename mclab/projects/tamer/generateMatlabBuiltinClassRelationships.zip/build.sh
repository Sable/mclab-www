#!/bin/bash

python gen.py
echo  "runall; exit;" | matlab -nodisplay 
tred tree.dot | dot -Tpng > tree.png


