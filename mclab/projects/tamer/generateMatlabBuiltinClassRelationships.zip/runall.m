function runall(f)
  if (nargin == 0)
    f = fopen('tree.dot','w');
  end
  v = values();

  fprintf(f,'digraph Overloading{\n');
  for i = 1:numel(v)
    for j = 1:i
      % check both ways - if one is dominant, print that
      res1 = atest(v{i}.value,v{j}.value);
      res2 = atest(v{j}.value,v{i}.value);
      if (isequal(res1,res2) && ~isequal(v{i}.class,v{j}.class))
        if (isequal(res1,v{i}.class))
          fprintf(f,'%s -> %s;\n',v{i}.class,v{j}.class);
        elseif (isequal(res1,v{j}.class))
          fprintf(f,'%s -> %s;\n',v{j}.class,v{i}.class);
        else
          fprintf('-----bad!---------\n')
        end
      end
    end
  end
  fprintf(f,'}\n');
  if (nargin == 0)
    fclose(f);
  end
end
  





