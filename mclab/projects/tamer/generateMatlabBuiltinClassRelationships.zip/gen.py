
# list of tuples with
# - name of class
# - optionally a matlab expr that generates an obj of the type
fname = 'atest'
oname = 'anObject'
classes = [('single',),
           ('double',),
           ('int8',),
           ('int16',),
           ('int32',),
           ('int64',),
           ('uint8',),
           ('uint16',),
           ('uint32',),
           ('uint64',),
           ('function_handle','@sin'),
           ('logical',),
           ('struct','struct()'),
           ('cell','{{}}'),
           ('char',),
           (oname,oname+'()')]


# remove files
import os, sys
os.system('rm -r @*');

# generate overloaded files
for i in range(0,len(classes)):
    t = classes[i]
    type = t[0]
    print type
    os.system('mkdir @'+type)

    f = open('@'+type+'/'+fname+'.m','w');
    f.write('function r = '+fname+'(a,b)\n')
    f.write("  r = '"+type+"';\n")
    f.write('end\n');
    f.close();

# generate class constructor
f = open('@'+oname+'/'+oname+'.m','w')
f.write("""function r = {name}()
  r = class(struct(),'{name}');
end """.format(name=oname))
f.close()

# generate values matlab - returns cell array of object values
f = open('values.m','w');
f.write('function r = values()\n')
f.write('r = {...\n')
for i in range(0,len(classes)):
    t = classes[i]
    # an expression is specified
    if (len(t) > 1):
        e = t[1]
    # otherwise cast 0 to class
    else:
        e = t[0]+'(0)'
    # put entry
    f.write("struct('class','"+t[0]+"','value',"+e+"),...\n");
f.write('};\nend\n');
f.close()



    





