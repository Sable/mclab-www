This little project will use Matlab to find the superior/inferior
relationships of the Matlab builtin classes. The gen.py will generate
a bunch of overloaded versions of a function, for every builtin
mclass (and some object); the runall method will use Matlab itself
to find the precedence relationships.

One needs python and Matlab to run this, and graphviz to process the
graph (tred to remove transitive edges, dot to create png).
The build.sh should generate the tree.png file.
